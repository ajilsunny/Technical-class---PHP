<?php
include("dbconnect.php");
if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$place=$_POST['place'];
	$email=$_POST['email'];
	$password=$_POST['pswd'];
	$sql="insert into register(name,phoneno,place,email,password)values('$name','$phone','$place','$email','$password')";
	$sql1="insert into login(username,password)values('$email','$password')";
	mysql_query($sql,$conn);
	mysql_query($sql1,$conn);
}
?>