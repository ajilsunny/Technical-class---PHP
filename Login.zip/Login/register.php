<html>
<body background="img1.jpg">
<form action="action.php" method="POST">
<center>
<br>
<br>
<h1>Register here....</h1>
<table border="1">
<br>
<br>
<br>
<tr><td>name:</td><td><input type="text" name="name" ></td></tr>
<tr><td>phone:</td><td><input type="text" name="phone" ></td></tr>
<tr><td>place:</td><td><input type="text" name="place" ></td></tr>
<tr><td>email:</td><td><input type="email" name="email" ></td></tr>

<tr><td>password:</td><td><input type="password" name="pswd" ></td></tr>
</table></center>
<br>
<br>
<center><input type="submit" name="submit" value="register"><br>

</center>
</form>
</body>
</html>