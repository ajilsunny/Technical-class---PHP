<?php
$conn=@mysql_connect("localhost","root","") or die("unable to connect");
@mysql_select_db("registeration",$conn) or die("could not select database");
?>