<?php
session_start();
include('dbconnect.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$password=$_POST['pswd'];

$sql="select * from login where username='$name'&& password='$password'";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
//echo $rowcount;
if($rowcount!=0)
{
	 $_SESSION['uname']=$name;
	  $_SESSION['password']=$password;
	  header("location:loginhome.php");
}
else
{
	header("location:login.php");
}
}
?>