<html>
<body background="image.jpg">
<form action="loginaction.php" method="POST">
<center><table border="1">
<br>
<br>
<br>
<br>
<br>
<tr><td><font color ="red">username:</font></td><td><input type="text" name="name" required></td></tr>

<tr><td><font color="red">password:</font></td><td><input type="password" name="pswd" required></td></tr>
</table></center>
<br>
<br>
<center><input type="submit" name="submit" value="login"><br>
<a href="register.php">register here</a>
</center>
</form>
</body>
</html>